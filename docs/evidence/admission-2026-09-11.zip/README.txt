Ten paired full-suite runs on 2026-09-11.
AMD Ryzen 7 7735HS, x86_64-pc-windows-msvc, Rust 1.96.0, LLVM 22.1.2.
Release profile with fat LTO and one codegen unit.
Compared event and router cells use 2,000 samples. Other cells use workload-specific budgets.
Pairs 1 through 5 run before first. Pairs 6 through 10 run after first.
Baseline code is c3d5efd. Candidate code is 1cebd63.
Before executable SHA-256
1b7288be14b7574cb78be382d35ecb981d00d2b2d75c42b1b975fe907866ad75
After executable SHA-256
2ca42b42e287d56b4d29f6b4cad039f6dfac531d47d8eff036058cb2ab58c33f
Every pair contains 103 matching workload cells, checksums and allocation counts.
Recovery cells allocate on cold paths. Measured hot paths remain allocation-free.
