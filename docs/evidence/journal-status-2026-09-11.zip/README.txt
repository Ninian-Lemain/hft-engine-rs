Ten paired full-suite runs on 2026-09-11.
AMD Ryzen 7 7735HS, x86_64-pc-windows-msvc, Rust 1.96.0, LLVM 22.1.2.
Release profile with fat LTO and one codegen unit.
Pairs 1 through 5 run before first. Pairs 6 through 10 run after first.
Baseline code is 1acb481 with the four benchmark workload and schema files
from 658704a applied unchanged. Candidate code is 658704a.
Before executable SHA-256
f86418ee0f00e4ef4c054c3b9f279b24b898f628c8a0970f7b05e84c540bb24d
After executable SHA-256
55a21607039c50beb5b081e08afd0589e4250bc6426454e2cc2cf8aa0b35af5d
Every pair contains 110 matching workload cells, sample counts, checksums,
allocation counts and deallocation counts.
Controlled enqueue uses 2,000 samples. Controlled persistence uses 1,023,
127 and 31 batches for batch sizes 1, 8 and 32. Timings are per record.
Other cells use workload-specific budgets. Recovery cells allocate on cold paths.
The persistence sink is fixed memory, not disk. Desktop timing includes outliers.
