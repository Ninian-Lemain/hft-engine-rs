Initial experiment on 2026-09-12. Not the retained implementation.
Ten paired full-suite runs on AMD Ryzen 7 7735HS, Windows x86_64, Rust 1.96.0,
LLVM 22.1.2. Release profile uses fat LTO and one codegen unit.
No process affinity was set. Pairs 1 through 5 ran before first.
Pairs 6 through 10 ran after first.
Baseline is 011ca7b with benchmark changes from 1dca1b5.
Candidate has the book changes retained in cf9c1fb and an uncommitted route
variant that probes a checked offset before falling back to binary search.
That route variant was replaced with construction-time strategy selection.
Its binary was replaced by the final build. These files retain its observations.
Before executable SHA-256
65f118d58d93b1cb6fa0d87b8616d296fe65d0ea2405093505cc09babd8d736d
After executable SHA-256
bbc4e09bc981b514f26f039eb7afd756f4e1b9e8858426643df596cfe22801ca
All 124 cells matched checksums, sample counts, allocation counts and parameters
other than structure sizes. Recovery allocates on cold paths.
