Final comparison on 2026-09-12.
AMD Ryzen 7 7735HS, x86_64-pc-windows-msvc, Rust 1.96.0, LLVM 22.1.2.
Release profile uses fat LTO and one codegen unit.
Ten paired full-suite runs. Both builds were launched with Windows start
/b /wait /affinity 4, selecting logical CPU 2. The CPU was not isolated.
Pairs 1 through 5 ran before first. Pairs 6 through 10 ran after first.
Baseline is 011ca7b with benchmark changes from 1dca1b5.
Candidate is 795908a. No default feature changes or custom compiler flags.
Before executable SHA-256
65f118d58d93b1cb6fa0d87b8616d296fe65d0ea2405093505cc09babd8d736d
After executable SHA-256
631d7bf7b3a6a0aa1669ba9db6827bbd3c7579ed85c221f73a884f99f7a03e42
All 124 cells matched checksums, sample counts, allocation counts and parameters
other than structure sizes. Recovery allocates on cold paths.
Top-level samples read both bid and ask. Each has 2,000 samples after 64 warmup
iterations. Update samples submit, read both sides, cancel, then read both sides.
Lookup cells use 2,000 batches of 64 calls after 128 warmup batches. Timings are
integer nanoseconds per call, including batch loop and result storage costs.
Mixed queries alternate hits and misses. Misses include out-of-range IDs and,
for sparse routes, interior holes. Other workloads retain their own budgets.
The final soak file contains all four retained seeds at one million declared
steps each, with each suite repeated internally. It is not multi-hour evidence.
