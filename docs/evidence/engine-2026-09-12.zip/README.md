# Engine admission measurements

Source commit `14f01b6441eeb879181378b9d5a55213b949fe1d`.
Built with `cargo build --release -p hft-bench`.
Binary SHA-256 `cbbb89191dba480ab6675cfc756b32744df84d41f83fb0342b985e49f8c84f7d`.

The host was a Lenovo 83J3 with an AMD Ryzen 7 7735HS, 8 cores, 16 logical
processors, and 29,318,848,512 bytes of RAM. Windows 11 Home build 26200 had
Hyper-V active. Rust was 1.96.0, commit ac68faa20c58cbccd01ee7208bf3b6e93a7d7f96,
with LLVM 22.1.2 and target x86_64-pc-windows-msvc. The workspace release
profile uses fat LTO, one codegen unit, and aborting panics. RUSTFLAGS,
CARGO_ENCODED_RUSTFLAGS, and CARGO_BUILD_TARGET were unset.

Ten complete suite processes ran on logical CPU 2 using Windows affinity mask
0x4. The CPU was not isolated. Frequency, governor, IRQ placement, and NUMA
placement were not controlled. No hardware counters were collected.

Each JSONL file contains 126 cells. Cell identity, parameters, sample count,
checksum, allocations, and deallocations matched across all ten runs.

The engine cells use one account, eight risk orders, two levels per side,
four orders per level, two reports, four events per batch, and two event queue
slots. The journal queue holds 1,024 records. Each cell runs 128 warmup commands
and 2,000 measured commands. Odd sequences submit one GTC buy at price 100 with
quantity 2. Even sequences cancel that order.

Composition runs before the facade in every process. Both paths use the same
command fixture and compare final snapshot digests. Timings include admission,
journal record encoding and enqueue, matching, and event publication. Timings
exclude event drain and persistence drain. The persistence worker uses batch
size one, OnShutdown flush, and a sink that discards bytes. No file durability
latency is measured. Allocation checks also cover the untimed drains.

The direct path composes event admission and the journal writer. The facade
also polls persistence failure and checks writer/gateway sequence alignment.
This is a same-binary boundary comparison, not a before/after optimization.

Median run means were 137 ns for composition and 140.5 ns for the facade,
a 3.5 ns (+2.6%) difference. Run means ranged from 125 to 190 ns and 125 to
252 ns respectively. Both cells recorded zero allocations and deallocations
and checksum 0000000000227068. Timer quantization, fixed run order, and shared
host activity limit conclusions about these small timing differences.

Admission owner and queue storage was 69,560 bytes for composition and 69,648
bytes for the facade. The 88-byte increase is 0.13%. These totals exclude the
event consumer, persistence worker, and benchmark arrays. They describe this
x86_64 shape only. Linux qualification remains open.
